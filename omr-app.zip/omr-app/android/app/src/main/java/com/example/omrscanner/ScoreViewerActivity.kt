package com.example.omrscanner

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

/**
 * Full-screen viewer that renders a MusicXML file as sheet music using
 * OpenSheetMusicDisplay (loaded from CDN) inside a WebView. Requires
 * internet access on first render since the OSMD library itself is fetched
 * from a CDN; the MusicXML content is passed in locally via a JS bridge, no
 * further network calls are made for that part.
 */
class ScoreViewerActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val path = intent.getStringExtra(EXTRA_MUSICXML_PATH)
            ?: throw IllegalArgumentException("Missing $EXTRA_MUSICXML_PATH extra")
        val musicXml = File(path).readText()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ScoreWebView(musicXml)
                }
            }
        }
    }

    companion object {
        const val EXTRA_MUSICXML_PATH = "extra_musicxml_path"
    }
}

/** Exposes the MusicXML string to the JS running in score_viewer.html. */
private class MusicXmlBridge(private val xml: String) {
    @JavascriptInterface
    fun getMusicXml(): String = xml
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ScoreWebView(musicXml: String) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                addJavascriptInterface(MusicXmlBridge(musicXml), "AndroidBridge")
                loadUrl("file:///android_asset/score_viewer.html")
            }
        }
    )
}
