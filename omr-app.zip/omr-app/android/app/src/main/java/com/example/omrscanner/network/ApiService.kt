package com.example.omrscanner.network

import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Streaming

data class RecognizeResponse(
    val job_id: String,
    val musicxml_url: String,
    val midi_url: String,
    val pages_merged: Int = 1,
    val uniform_parts: Boolean = true
)

interface OmrApiService {

    @Multipart
    @POST("recognize")
    suspend fun recognize(@Part file: MultipartBody.Part): Response<RecognizeResponse>

    @Streaming
    @GET("download/{jobId}/{kind}")
    suspend fun download(
        @Path("jobId") jobId: String,
        @Path("kind") kind: String
    ): Response<ResponseBody>
}
