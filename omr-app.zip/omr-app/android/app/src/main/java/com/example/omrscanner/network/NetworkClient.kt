package com.example.omrscanner.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkClient {

    /**
     * Address of the backend from backend/ (see backend/README.md for deployment).
     *
     * - 10.0.2.2 is the special alias the Android EMULATOR uses to reach
     *   "localhost" on your development machine.
     * - On a REAL tablet you must replace this with your machine/server's
     *   actual LAN IP or public URL, e.g. "http://192.168.1.50:8080/" or
     *   "https://your-domain.com/".
     */
    var baseUrl: String = "http://10.0.2.2:8080/"
        set(value) {
            field = if (value.endsWith("/")) value else "$value/"
            rebuild()
        }

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)   // recognition can take a while
        .writeTimeout(300, TimeUnit.SECONDS)
        .build()

    private var _api: OmrApiService = build()

    val api: OmrApiService
        get() = _api

    private fun build(): OmrApiService =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OmrApiService::class.java)

    private fun rebuild() {
        _api = build()
    }
}
