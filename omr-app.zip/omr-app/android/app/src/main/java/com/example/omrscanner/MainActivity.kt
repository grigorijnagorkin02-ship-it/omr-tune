package com.example.omrscanner

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.omrscanner.network.NetworkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream

/** UI state machine for the single recognition screen. */
sealed class UiState {
    data object Idle : UiState()
    data object Uploading : UiState()
    data class Done(
        val jobId: String,
        val midiFile: File,
        val musicXmlFile: File,
        val pagesMerged: Int,
        val uniformParts: Boolean
    ) : UiState()
    data class Error(val message: String) : UiState()
}

class MainActivity : ComponentActivity() {

    // Holds the path of the file the camera intent is about to write into.
    var pendingCameraFile: File? = null
        private set

    fun preparePendingCameraFile(): Uri {
        val dir = File(getExternalFilesDir(null), "images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        pendingCameraFile = file
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    OmrScreen()
                }
            }
        }
    }
}

@Composable
fun OmrScreen() {
    val context = LocalContext.current
    val activity = context as MainActivity
    val scope = rememberCoroutineScope()

    var uiState by remember { mutableStateOf<UiState>(UiState.Idle) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    DisposableEffect(Unit) {
        onDispose { mediaPlayer?.release() }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            activity.pendingCameraFile?.let { file ->
                scope.launch {
                    uploadFile(context, file, "image/jpeg") { uiState = it }
                }
            }
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                val file = copyUriToCache(context, it)
                val mime = context.contentResolver.getType(it) ?: "application/octet-stream"
                uploadFile(context, file, mime) { uiState = it }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("OMR Scanner", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Сфотографируй ноты или выбери файл — получишь MusicXML и звук",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(Modifier.height(32.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(onClick = {
                uiState = UiState.Idle
                val uri = activity.preparePendingCameraFile()
                pendingCameraUri = uri
                cameraLauncher.launch(uri)
            }) {
                Text("📷 Снять фото")
            }

            OutlinedButton(onClick = {
                uiState = UiState.Idle
                galleryLauncher.launch("image/*")
            }) {
                Text("🖼 Из галереи / PDF")
            }
        }

        Spacer(Modifier.height(32.dp))

        when (val state = uiState) {
            is UiState.Idle ->
                Text("Ожидание файла...", style = MaterialTheme.typography.bodyMedium)

            is UiState.Uploading -> {
                CircularProgressIndicator()
                Spacer(Modifier.height(8.dp))
                Text("Распознаём ноты (может занять до минуты)...")
            }

            is UiState.Error ->
                Text(
                    "Ошибка: ${state.message}",
                    color = MaterialTheme.colorScheme.error
                )

            is UiState.Done -> {
                Text("✅ Ноты распознаны")
                if (state.pagesMerged > 1) {
                    Text(
                        "Склеено страниц: ${state.pagesMerged}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!state.uniformParts) {
                        Text(
                            "⚠ На разных страницах разное число партий — " +
                                "склейка могла получиться неидеальной, проверьте партитуру",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Button(onClick = {
                        mediaPlayer?.release()
                        val mp = MediaPlayer().apply {
                            setDataSource(state.midiFile.absolutePath)
                            setOnCompletionListener { isPlaying = false }
                            prepare()
                            start()
                        }
                        mediaPlayer = mp
                        isPlaying = true
                    }) {
                        Text(if (isPlaying) "▶ Играет..." else "▶ Проиграть")
                    }

                    OutlinedButton(onClick = {
                        mediaPlayer?.pause()
                        isPlaying = false
                    }) {
                        Text("⏸ Стоп")
                    }

                    OutlinedButton(onClick = {
                        val intent = Intent(context, ScoreViewerActivity::class.java).apply {
                            putExtra(ScoreViewerActivity.EXTRA_MUSICXML_PATH, state.musicXmlFile.absolutePath)
                        }
                        context.startActivity(intent)
                    }) {
                        Text("📄 Показать партитуру")
                    }

                    OutlinedButton(onClick = {
                        shareFile(context, state.musicXmlFile, "application/vnd.recordare.musicxml")
                    }) {
                        Text("📤 Экспорт MusicXML")
                    }
                }
            }
        }
    }
}

/** Uploads [file] to the backend, downloads the resulting MIDI + MusicXML, updates [onState]. */
suspend fun uploadFile(
    context: Context,
    file: File,
    mime: String,
    onState: (UiState) -> Unit
) {
    onState(UiState.Uploading)
    try {
        val result = withContext(Dispatchers.IO) {
            val requestFile = file.asRequestBody(mime.toMediaTypeOrNull())
            val part = MultipartBody.Part.createFormData("file", file.name, requestFile)

            val response = NetworkClient.api.recognize(part)
            if (!response.isSuccessful) {
                throw RuntimeException("Сервер вернул ошибку: ${response.code()}")
            }
            val body = response.body() ?: throw RuntimeException("Пустой ответ сервера")

            val midiResp = NetworkClient.api.download(body.job_id, "midi")
            val midiBytes = midiResp.body()?.bytes()
                ?: throw RuntimeException("Не удалось получить MIDI")
            val midiFile = File(context.cacheDir, "${body.job_id}.mid")
            FileOutputStream(midiFile).use { it.write(midiBytes) }

            val xmlResp = NetworkClient.api.download(body.job_id, "musicxml")
            val xmlBytes = xmlResp.body()?.bytes()
                ?: throw RuntimeException("Не удалось получить MusicXML")
            val xmlFile = File(context.cacheDir, "${body.job_id}.musicxml")
            FileOutputStream(xmlFile).use { it.write(xmlBytes) }

            UiState.Done(
                jobId = body.job_id,
                midiFile = midiFile,
                musicXmlFile = xmlFile,
                pagesMerged = body.pages_merged,
                uniformParts = body.uniform_parts
            )
        }
        onState(result)
    } catch (e: Exception) {
        onState(UiState.Error(e.message ?: "неизвестная ошибка"))
    }
}

fun copyUriToCache(context: Context, uri: Uri): File {
    val mime = context.contentResolver.getType(uri) ?: ""
    val ext = if (mime.contains("pdf")) "pdf" else "jpg"
    val file = File(context.cacheDir, "picked_${System.currentTimeMillis()}.$ext")
    context.contentResolver.openInputStream(uri)?.use { input ->
        FileOutputStream(file).use { output -> input.copyTo(output) }
    }
    return file
}

fun shareFile(context: Context, file: File, mimeType: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Поделиться MusicXML"))
}
