"""
OMR backend service.

Wraps the Audiveris OMR engine (https://github.com/Audiveris/audiveris) in a
small REST API:

  POST /recognize
      multipart/form-data, field "file" = image (jpg/png) or PDF of sheet music
      -> { "job_id": ..., "musicxml_url": ..., "midi_url": ... }

  GET /download/<job_id>/musicxml
  GET /download/<job_id>/midi
      -> the produced files

  GET /health
      -> simple liveness check

Audiveris does the actual optical music recognition (staff detection, note
heads, rhythm, clefs, key signatures, etc.). For a single image it exports one
MusicXML file. For a multi-page PDF, Audiveris treats each page as a separate
"sheet" and (depending on version/config) may export one file per sheet rather
than a single merged score. To make sure the app always gets ONE continuous
piece of music regardless of how many pages were photographed, this service:

  1. Runs Audiveris on the input file.
  2. Collects every MusicXML file it produced (there may be several, one per
     page).
  3. If there's more than one, merges them in page order into a single
     music21 Score (appending each page's measures onto the corresponding
     part).
  4. Writes out one final "combined.musicxml" and one "output.mid".

This merge is a best-effort heuristic: it works well when every page has the
same instrumentation/part layout (typical for a single piano/song score
split across pages). Pages with a different number of parts than page 1 are
appended as new parts rather than merged measure-by-measure -- flagged in the
response so the app can warn the user if that happens.
"""

import os
import subprocess
import uuid
import shutil
import logging

from flask import Flask, request, jsonify, send_file
from music21 import converter, stream, note

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("omr-backend")

app = Flask(__name__)

DATA_ROOT = os.environ.get("OMR_DATA_ROOT", "/data")
UPLOAD_DIR = os.path.join(DATA_ROOT, "uploads")
OUTPUT_DIR = os.path.join(DATA_ROOT, "outputs")
AUDIVERIS_TIMEOUT_SEC = int(os.environ.get("AUDIVERIS_TIMEOUT_SEC", "300"))

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf", ".tif", ".tiff", ".bmp"}
MXL_EXTENSIONS = (".mxl", ".musicxml", ".xml")


def _validate_filename(filename: str) -> str:
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {ext}")
    return ext


def run_audiveris(input_path: str, output_dir: str) -> list[str]:
    """
    Runs Audiveris in headless batch mode on the given image/PDF and asks it
    to export MusicXML into output_dir. Returns paths to every MusicXML file
    produced, sorted in page order (Audiveris names multi-sheet output with
    zero-padded sheet numbers, so a plain sort is enough).
    """
    cmd = [
        "audiveris",
        "-batch",
        "-export",
        "-output", output_dir,
        "--",
        input_path,
    ]
    log.info("Running: %s", " ".join(cmd))
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=AUDIVERIS_TIMEOUT_SEC,
    )
    if result.returncode != 0:
        log.error("Audiveris stderr: %s", result.stderr[-4000:])
        raise RuntimeError("Audiveris failed to process the file")

    found = []
    for root, _dirs, files in os.walk(output_dir):
        for fname in files:
            if fname.endswith(MXL_EXTENSIONS):
                found.append(os.path.join(root, fname))

    if not found:
        raise RuntimeError("Audiveris produced no MusicXML output (recognition likely failed)")

    found.sort()
    return found


def _part_key(part):
    """
    Best-effort stable identifier for a part, used to match the SAME
    instrument across pages. Positional matching (part #5 on page 1 ==
    part #5 on page 2) breaks for orchestral scores, where printed editions
    routinely omit staves for instruments that don't play in a given system
    -- so the raw number and order of parts can differ page to page even
    though it's still the same piece. Matching by instrument name/id is far
    more robust for that case.
    """
    if part.partName:
        return part.partName.strip().lower()
    if part.id:
        return str(part.id).strip().lower()
    return None


def _measure_count(part):
    return len(part.getElementsByClass("Measure"))


def _pad_with_rests(part, target_count):
    """
    Appends full-measure rests to `part` until it has `target_count`
    measures. Used when an instrument was entirely omitted from a page (a
    common orchestral engraving practice for tacet parts) so every part in
    the merged score stays aligned in time with the others.

    Assumes 4/4 for the padding measures, which is a simplification: if the
    tacet page actually used a different time signature, the total padded
    duration will still be roughly right for playback, but barlines may not
    land exactly where they would in the original. Good enough to keep
    playback and rough alignment correct; may need a manual nudge in
    MuseScore for scores with unusual meters.
    """
    existing = _measure_count(part)
    for _ in range(target_count - existing):
        m = stream.Measure()
        m.append(note.Rest(quarterLength=4.0))
        part.append(m)


def merge_pages(mxl_paths: list[str]) -> tuple[stream.Score, bool]:
    """
    Merges one or more per-page MusicXML files into a single continuous
    music21 Score, in the given (page) order.

    Parts are matched across pages by instrument name/id when available
    (robust to orchestral scores where tacet instruments are omitted from
    some pages' systems), falling back to strict positional matching when no
    name/id survived the OMR export.

    Returns (merged_score, uniform_parts) where uniform_parts is False if any
    page required padding (a part was missing) or contained an instrument
    not seen on page 1 -- signal to the caller that the merge is a
    best-effort heuristic worth double-checking.
    """
    scores = [converter.parse(p) for p in mxl_paths]
    if len(scores) == 1:
        return scores[0], True

    base = scores[0]
    base_parts = list(base.parts)
    base_keys = [_part_key(p) for p in base_parts]
    uniform = True
    can_match_by_name = all(k is not None for k in base_keys)

    for extra in scores[1:]:
        extra_parts = list(extra.parts)
        extra_keys = [_part_key(p) for p in extra_parts]
        page_measure_count = max((_measure_count(p) for p in extra_parts), default=0)

        if can_match_by_name and all(k is not None for k in extra_keys):
            matched_base_indices = set()

            for i, key in enumerate(extra_keys):
                if key in base_keys:
                    target_idx = base_keys.index(key)
                    for measure in extra_parts[i].getElementsByClass("Measure"):
                        base_parts[target_idx].append(measure)
                    matched_base_indices.add(target_idx)
                else:
                    # An instrument that wasn't on page 1 (e.g. a soloist
                    # who only enters later) -- add it as a new part.
                    uniform = False
                    base.insert(0, extra_parts[i])
                    base_parts.append(extra_parts[i])
                    base_keys.append(key)
                    matched_base_indices.add(len(base_parts) - 1)

            # Any existing part with no counterpart on this page was
            # presumably tacet and omitted from the printed page -- pad it
            # with rests so every part stays aligned in time.
            for idx, part in enumerate(base_parts):
                if idx not in matched_base_indices:
                    uniform = False
                    _pad_with_rests(part, page_measure_count)
        else:
            # No usable instrument names -- fall back to strict positional
            # matching (fine for e.g. piano scores with consistent layout).
            if len(extra_parts) != len(base_parts):
                uniform = False
                for part in extra_parts:
                    base.insert(0, part)
                continue
            for i, part in enumerate(extra_parts):
                for measure in part.getElementsByClass("Measure"):
                    base_parts[i].append(measure)

    return base, uniform


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/recognize", methods=["POST"])
def recognize():
    if "file" not in request.files:
        return jsonify({"error": "no file provided (expected multipart field 'file')"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "empty filename"}), 400

    try:
        _validate_filename(f.filename)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    job_id = str(uuid.uuid4())
    job_upload_dir = os.path.join(UPLOAD_DIR, job_id)
    job_output_dir = os.path.join(OUTPUT_DIR, job_id)
    os.makedirs(job_upload_dir, exist_ok=True)
    os.makedirs(job_output_dir, exist_ok=True)

    input_path = os.path.join(job_upload_dir, f.filename)
    f.save(input_path)

    try:
        page_files = run_audiveris(input_path, job_output_dir)
        merged_score, uniform_parts = merge_pages(page_files)

        combined_xml_path = os.path.join(job_output_dir, "combined.musicxml")
        midi_path = os.path.join(job_output_dir, "output.mid")

        merged_score.write("musicxml", fp=combined_xml_path)
        merged_score.write("midi", fp=midi_path)
    except subprocess.TimeoutExpired:
        shutil.rmtree(job_upload_dir, ignore_errors=True)
        shutil.rmtree(job_output_dir, ignore_errors=True)
        return jsonify({"error": "recognition timed out"}), 504
    except Exception as e:
        log.exception("recognition failed")
        shutil.rmtree(job_upload_dir, ignore_errors=True)
        shutil.rmtree(job_output_dir, ignore_errors=True)
        return jsonify({"error": str(e)}), 500

    return jsonify({
        "job_id": job_id,
        "pages_merged": len(page_files),
        "uniform_parts": uniform_parts,
        "musicxml_url": f"/download/{job_id}/musicxml",
        "midi_url": f"/download/{job_id}/midi",
    })


@app.route("/download/<job_id>/<kind>", methods=["GET"])
def download(job_id, kind):
    job_output_dir = os.path.join(OUTPUT_DIR, job_id)
    if not os.path.isdir(job_output_dir):
        return jsonify({"error": "unknown job_id"}), 404

    if kind == "musicxml":
        path = os.path.join(job_output_dir, "combined.musicxml")
        if os.path.isfile(path):
            return send_file(path, as_attachment=True, mimetype="application/vnd.recordare.musicxml+xml")
        return jsonify({"error": "musicxml not found"}), 404

    if kind == "midi":
        path = os.path.join(job_output_dir, "output.mid")
        if os.path.isfile(path):
            return send_file(path, as_attachment=True, mimetype="audio/midi")
        return jsonify({"error": "midi not found"}), 404

    return jsonify({"error": "unknown kind, expected 'musicxml' or 'midi'"}), 400


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
